library(testthat)
library(analysisready)

test_check("analysisready")
